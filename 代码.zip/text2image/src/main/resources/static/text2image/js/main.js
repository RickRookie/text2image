var navs = document.getElementsByClassName('nav')[0].children;
var pages = document.getElementsByTagName('main')[0].children;

// 清除active
function clearActive() {
    for (var i = 0; i < navs.length; i++) {
        navs[i].className = '';
    }
    for (var i = 0; i < pages.length; i++) {
        pages[i].className = '';
    }
}

//导航栏点击事件
for (var i = 0; i < navs.length-1; i++) {
    navs[i].setAttribute("index", i); // 为每一个nav添加索引号

    navs[i].onclick = function () { // 当点中其中一个nav
        clearActive(); // 先清空完active

        this.className = 'active'; // 再为当前的nav添加active

        var index = this.getAttribute("index"); // 获取到当前索引号
        var flag = Number(index);

        pages[index].className = 'page-active'; // 利用对应索引为对应内容块添加active
        if (flag !== 0) {
            show_items(flag);
        }

    }
}

//管理员登陆
var exit = document.getElementById("exit");
exit.onclick = function () {
     // window.open('/login.html','_self')
    location.href="/adminlogin";

};


//创建XMLHttpRequest，用于在后台与服务器交换数据
function loadXMLDoc(url,cfunc)
{
    if (window.XMLHttpRequest)
    {// IE7+, Firefox, Chrome, Opera, Safari 代码
        xmlhttp=new XMLHttpRequest();
    }
    else
    {// IE6, IE5 代码
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=cfunc;
    xmlhttp.open("GET",url,true);
    xmlhttp.send();
}

//加载表格数据
function show_items(flag)
{
    loadXMLDoc("test-data/response.txt",function()
    {
        if (xmlhttp.readyState===4 && xmlhttp.status===200)
        {
            var tempStr=xmlhttp.responseText;
            var myobj=eval('('+tempStr+')');
            // 这是请求本地数据的测试，后端根据请求参数查询相应数据返回即可
            switch (flag)
            {
                case 1:
                    var html1 ="";
                    var paper_item = document.getElementById("papers")
                    for(var i=0; i< myobj.papers.length; i++){
                        html1 += "<tr><td><p>" + myobj.papers[i].name + "</p></td>"+
                             "<td><p>" + myobj.papers[i].time +"</p></td>" +
                             "<td><a href="+myobj.papers[i].url+" download="+myobj.papers[i].name+">"+
                             "<button type=\"button\" class=\"btn btn-primary\">" +
                             "<span class=\"glyphicon glyphicon-download-alt\">下载</span></button>"+
                             "</a></td></tr>";
                    }
                    paper_item.innerHTML=html1;
                    break;

                //冗余代码，统一接口数据格式后合并
                case 2:
                    var html2 ="";
                    var dataset_item = document.getElementById("datasets")
                    for(var j=0; j< myobj.datasets.length; j++){
                        html2 += "<tr><td><p>" + myobj.datasets[j].name + "</p></td>"+
                            "<td><p>" + myobj.datasets[j].time +"</p></td>" +
                            "<td><a href="+myobj.datasets[j].url+" download="+myobj.datasets[j].name+">"+
                            "<button type=\"button\" class=\"btn btn-primary\">" +
                            "<span class=\"glyphicon glyphicon-download-alt\">下载</span></button>"+
                            "</a></td></tr>";
                    }
                    dataset_item.innerHTML=html2;
                    break;

                case 3:
                    var html3 ="";
                    var model_item = document.getElementById("models")
                    for(var k=0; k< myobj.models.length; k++){
                        html3 += "<tr><td><p>" + myobj.models[k].name + "</p></td>"+
                            "<td><p>" + myobj.models[k].time +"</p></td>" +
                            "<td><a href="+myobj.models[k].url+" download="+myobj.models[k].name+">"+
                            "<button type=\"button\" class=\"btn btn-primary\">" +
                            "<span class=\"glyphicon glyphicon-download-alt\">下载</span></button>"+
                            "</a></td></tr>";
                    }
                    model_item.innerHTML=html3;
                    break;
            }
        }
    });
}

//联动选择框
var model = document.getElementById("mymodel");
model.onchange = function(){
    var modelname = document.getElementById("mymodel").value;
    if("AttnGAN"===modelname){
        document.getElementById("mydataset").options.length=0;
        var option1 = new Option("Bird", "Bird");
        document.getElementById("mydataset").options.add(option1);
        var option2 = new Option("flower", "flower");
        document.getElementById("mydataset").options.add(option2);
        var option3 = new Option("Coco", "Coco");
        document.getElementById("mydataset").options.add(option3);
    }
    else if("StackGAN-v2"===modelname){
        document.getElementById("mydataset").options.length=0;
        var option11 = new Option("Bird", "Bird");
        document.getElementById("mydataset").options.add(option11);
    }
}

// 用户体验
var runbtn = document.getElementById("tryIt");
runbtn.onclick = function () {
    var para = {
        myText : $("#text").val(),
        mySelect1 : document.getElementById("mymodel").selectedIndex,
        mySelect2 : document.getElementById("mydataset").selectedIndex

    };



    if(para.myText===""){
        alert("输入内容不能为空~");
        return;
    }
    var re = new RegExp("^[a-zA-Z0-9\s\r,， 。![.]+$");
    if(!re.test(para.myText)) {
        if(para.mySelect2=="0"){
            alert("请输入描述鸟类的英语句子(不含回车)~");
            return;
        }

        if(para.mySelect2=="1"){
            alert("请输入描述花类的英语句子(不含回车)~");
            return;
        }

        if(para.mySelect2=="2"){
            alert("请输入描述性的英语句子(不含回车)~");
            return;
        }
        return;
    }
    $.ajax({
        url :"/try",                       //请求地址
        type: 'get',                  //获取数据方式:post/get
        async: false,                  //加载方式默认异步,true为同步
        dataType:'text',               //数据格式
        data : para, //前端发送数据
        success:function(data) {        //后端返回数据
            if (data !=null) {      //请求成功,根据后端情况更换
                var result = document.getElementById("result");
                alert("请稍等~");
                result.setAttribute("src", data);


            } else {//请求失败
                alert("哎呀，出错了！")
            }
        }
    });


};


//论文模糊查询
var paperresetbtn = document.getElementById("paperreset");
paperresetbtn.onclick = function(){
    $("#paperkeywords").val("");
    var papertable = document.getElementById("papers");//表格
    var paperlength = papertable.rows.length;//表格总共有多少行
    for(var i=0;i<paperlength;i++) {
        papertable.rows[i].style.display = '';//匹配成功，显示行
    }
}
var paperbtn = document.getElementById("searchpaper");
paperbtn.onclick = function (){
    setTimeout(function(){
        var paperkeywords = document.getElementById("paperkeywords").value;//搜索关键字
        var papertable = document.getElementById("papers");//表格
        var paperlength = papertable.rows.length;//表格总共有多少行
        var count = 0;
        for(var i=0;i<paperlength;i++){
            var paperinfo = papertable.rows[i].innerText;//每一行文本信息
            if(paperinfo.match(paperkeywords) || paperinfo.toUpperCase().match(paperkeywords.toUpperCase())){
                papertable.rows[i].style.display='';//匹配成功，显示行
            }else{
                papertable.rows[i].style.display='none';//匹配失败，隐藏行
                count++;
                if(count === paperlength) {//没有找到一条数据
                    alert("没有找到相关内容，请更换关键字试试！");
                }
            }
        }
    },20);
}


// 数据集模糊查询
var dataresetbtn = document.getElementById("datasetreset");
dataresetbtn.onclick = function(){
    $("#datasetkeywords").val("");
    var datasettable = document.getElementById("datasets");//表格
    var datasetlength = datasettable.rows.length;//表格总共有多少行
    for(var i=0;i<datasetlength;i++) {
        datasettable.rows[i].style.display = '';//匹配成功，显示行
    }
}
var datasetbtn = document.getElementById("searchdataset");
datasetbtn.onclick = function (){
    setTimeout(function(){
        var datasetkeywords = document.getElementById("datasetkeywords").value;//搜索关键字
        var datasettable = document.getElementById("datasets");//表格
        var datasetlength = datasettable.rows.length;//表格总共有多少行
        var count = 0;
        for(var i=0;i<datasetlength;i++){
            var datasetinfo = datasettable.rows[i].innerText;//每一行文本信息
            if(datasetinfo.match(datasetkeywords) || datasetinfo.toUpperCase().match(datasetkeywords.toUpperCase())){
                datasettable.rows[i].style.display='';//匹配成功，显示行
            }else{
                datasettable.rows[i].style.display='none';//匹配失败，隐藏行
                count++;
                if(count === datasetlength) {//没有找到一条数据
                    alert("没有找到相关内容，请更换关键字试试！");
                }
            }
        }
    },20);
}


// 模型模糊查询
var modelresetbtn = document.getElementById("modelreset");
modelresetbtn.onclick = function(){
    $("#modelkeywords").val("");
    var modeltable = document.getElementById("models");//表格
    var modellength = modeltable.rows.length;//表格总共有多少行
    for(var i=0;i<modellength;i++) {
        modeltable.rows[i].style.display = '';//显示行
    }
}
var modelbtn = document.getElementById("searchmodel");
modelbtn.onclick = function (){
    setTimeout(function(){
        var modelkeywords = document.getElementById("modelkeywords").value;//搜索关键字
        var modeltable = document.getElementById("models");//表格
        var modellength = modeltable.rows.length;//表格总共有多少行
        var count = 0;
        for(var i=0;i<modellength;i++){
            var modelinfo = modeltable.rows[i].innerText;//每一行文本信息
            if(modelinfo.match(modelkeywords) || modelinfo.toUpperCase().match(modelkeywords.toUpperCase())){
                modeltable.rows[i].style.display='';//匹配成功，显示行
            }else{
                modeltable.rows[i].style.display='none';//匹配失败，隐藏行
                count++;
                if(count === modellength) {//没有找到一条数据
                    alert("没有找到相关内容，请更换关键字试试！");
                }
            }
        }
    },20);
}