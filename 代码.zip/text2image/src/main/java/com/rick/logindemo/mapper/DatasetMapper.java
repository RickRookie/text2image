package com.rick.logindemo.mapper;

import com.rick.logindemo.entity.Dataset;
import com.rick.logindemo.entity.Dataset;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface DatasetMapper {

    public List<Dataset> getAllDataset();
    public List<Dataset> getDatasetBySource(String source);
    public String getDatasetPathByName(String name);

    public void insertDataset(Dataset Dataset);
    public Dataset getDatasetById(Integer id);
    public void editDatasetById(Dataset dataset);
    public void deleteDatasetById(Integer id);
}
