package com.rick.logindemo.controller;

import com.rick.logindemo.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

@Controller
public class LoginController {





    @Autowired
    UserMapper userMapper;

    @PostMapping(value = "/login")
    public String login(@RequestParam("username") String username,
                        @RequestParam("password") String password,
                        Map<String,Object> map,
                        HttpSession httpSession){
        List<String> userlist = userMapper.getAllUserName();


        if(!StringUtils.isEmpty(username)){

            if(!userlist.contains(username)){
                //无此管理员账户
                map.put("msg","无此管理员账户");
                return "login";
            } else {
                String userPassword = userMapper.getPasswordByUserName(username);
                if(userPassword.equals(password)) {
                    //登陆成功，防止表单重复提交，可以重定向到主页
                    httpSession.setAttribute("loginUser",username);

                     return "redirect:/main.html";
                } else{
                    map.put("msg","密码错误");
                    return "login";
                }
            }
        } else{
            map.put("msg","用户名密码错误");
            return "login";
        }
    }
}
