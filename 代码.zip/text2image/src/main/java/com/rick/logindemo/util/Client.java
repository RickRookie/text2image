package com.rick.logindemo.util;

import java.io.*;
import java.net.Socket;

public class Client {

    public String text;
    public String algorithm;
    public String dataset;
    public Socket s;
    public Client(String text,String algoritm, String dataset) {
        this.text = text;
        this.algorithm = algoritm;
        this.dataset = dataset;
    }

    public String doIt() throws Exception{
        if("0".equals(algorithm)){
            s = new Socket("sdu-Z390-AORUS-MASTER",12345);
        } else if("1".equals(algorithm)){
            s = new Socket("sdu-Z390-AORUS-MASTER",12346);
        }



        //构建IO
        InputStream is = s.getInputStream();
        OutputStream os = s.getOutputStream();

        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os));
        //向服务器端发送一条消息
        if("0".equals(dataset)){
            text = 'b'+text;
        } else if ("1".equals(dataset)){
            text = 'f'+text;
        } else if("2".equals(dataset)){
            text = 'c'+text;
        }
        bw.write(text);
        bw.flush();

        //读取服务器返回的消息
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String mess = br.readLine();
        System.out.println("服务器："+mess);
        return mess;
    }
}
