package com.rick.logindemo.mapper;


import com.rick.logindemo.entity.Paper;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface PaperMapper {
    public List<Paper> getAllPaper();
    public List<Paper> getPaperByReleaseTime(String releaseTime);
    public List<Paper> getPaperBySource(String source);
    public String getPaperPathByName(String name);

    public void insertPaper(Paper paper);
    public Paper getPaperById(Integer id);
    public void editPaperById(Paper paper);
    public void deletePaperById(Integer id);


    //public String getFileTypeByName(String name);
}
