package com.rick.logindemo.model;

import lombok.Data;

import java.util.Date;
import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

@Data
public class FileInfo {

    private String name;
    private Date uploadTime = new Date();

    public FileInfo setFileName(String name){
        this.setName ( name );
        return this;
    }

    public String getName() {
        return this.name;
    }
    public void setName(String name){
        this.name = name;
    }


    public static Map<String,FileInfo> getFile(String fileUploadRootDir) {
        Map<String,FileInfo> fileRepository = new HashMap<>();
        File file = new File(fileUploadRootDir);
        File[] fileList = file.listFiles();
        for(int i=0; i<fileList.length;++i){
            if(fileList[i].isFile()){
                FileInfo file1 = new FileInfo ().setFileName ( fileList[i].getName() );
                fileRepository.put ( file1.getName (),file1 );
            }
        }
        return fileRepository;
    }
}
