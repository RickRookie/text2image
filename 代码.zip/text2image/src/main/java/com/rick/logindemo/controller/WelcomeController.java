package com.rick.logindemo.controller;


import com.rick.logindemo.entity.Dataset;
import com.rick.logindemo.entity.MyModel;
import com.rick.logindemo.entity.Paper;
import com.rick.logindemo.mapper.DatasetMapper;
import com.rick.logindemo.mapper.MyModelMapper;
import com.rick.logindemo.mapper.PaperMapper;
import com.rick.logindemo.model.FileInfo;
import com.rick.logindemo.util.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Controller
public class WelcomeController {
    @Autowired
    PaperMapper paperMapper;

    @Autowired
    MyModelMapper myModelMapper;

    @Autowired
    DatasetMapper datasetMapper;


    private static List<Paper> paperList = new ArrayList<>();
    private static List<MyModel> myModelList = new ArrayList<>();
    private static List<Dataset> datasetList = new ArrayList<>();




//    @PostConstruct
//    public void initFileRepository(){
//
//
//        paperList = paperMapper.getAllPaper();
//        myModelList = myModelMapper.getAllModel();
//        for(int i=0;i<paperList.size();++i){
//            Paper paper = paperList.get(i);
//            fileRepository.put(paper.getName(),paper);
//
//        }
//        for(int i=0; i<myModelList.size();++i){
//            MyModel myModel = myModelList.get(i);
//            fileRepository2.put(myModel.getName(), myModel);
//        }
//
//
//    }




    @GetMapping("/text2image")
    public String welcome(Model model, HttpServletRequest request){

        Collection<Paper> papers = paperMapper.getAllPaper();
        Collection<MyModel> models = myModelMapper.getAllModel();
        Collection<Dataset> datasets = datasetMapper.getAllDataset();
        model.addAttribute("papers",papers);
        model.addAttribute("models",models);
        model.addAttribute("datasets",datasets);
        return "welcome";
    }

    @GetMapping("/try")
    @ResponseBody
    public String tryIt(String myText, String mySelect1, String mySelect2  ) throws Exception {


        String text = myText;
        String algorithm = mySelect1;
        String dataset = mySelect2;

      //  String src = "/text2image/images/img2.png";
        Client client = new Client(text,algorithm,dataset);
        String src = client.doIt();
        String dir = null;
        String bird_attn = "bird_AttnGAN2/";
        String coco_attn = "coco_AttnGAN2/";
        String flower_attn = "flower_AttnGAN2/";
        String bird_stackv2 = "bird_StackGANv2/";
        String coco_stackv2 = "coco_StackGANv2/";


        if("0".equals(algorithm)){
            if("0".equals(dataset)){
                dir = bird_attn+src+"/"+"img2.png";
            } else if("2".equals(dataset)){
                dir = coco_attn+src+"/"+"img2.png";
            } else if("1".equals(dataset)) {
                dir = flower_attn+src+"/"+"img2.png";
            }
        } else if("1".equals(algorithm)){

            if("0".equals(dataset)){
                dir = bird_stackv2+src+"/"+"img.png";
            } else if("2".equals(dataset)){
                dir = coco_stackv2+src+"/"+"img.png";
            }
        }


        return dir;

    }





}
