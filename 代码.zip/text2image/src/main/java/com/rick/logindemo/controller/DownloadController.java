package com.rick.logindemo.controller;

import com.rick.logindemo.mapper.DatasetMapper;
import com.rick.logindemo.mapper.MyModelMapper;
import com.rick.logindemo.mapper.PaperMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

@Controller
public class DownloadController {

    @Autowired
    PaperMapper paperMapper;

    @Autowired
    MyModelMapper myModelMapper;

    @Autowired
    DatasetMapper datasetMapper;

    @GetMapping("/download/{fileName}")
    @ResponseBody
    public ResponseEntity<Object> downloadFile(@PathVariable(name = "fileName") String fileName) throws FileNotFoundException {

        String path = paperMapper.getPaperPathByName(fileName);

        String download = path+fileName;
        File file = new File (download);
        InputStreamResource resource = new InputStreamResource ( new FileInputStream( file ) );

        HttpHeaders headers = new HttpHeaders();
        headers.add ( "Content-Disposition",String.format("attachment;filename=\"%s",fileName));
        headers.add ( "Cache-Control","no-cache,no-store,must-revalidate" );
        headers.add ( "Pragma","no-cache" );
        headers.add ( "Expires","0" );

        ResponseEntity<Object> responseEntity = ResponseEntity.ok()
                .headers ( headers )
                .contentLength ( file.length ())
                .contentType(MediaType.parseMediaType ( "application/txt" ))
                .body(resource);

        System.out.println("用户下载了文件："+fileName);
        return responseEntity;
    }

    @GetMapping("/download1/{fileName}")
    @ResponseBody
    public ResponseEntity<Object> downloadFile1(@PathVariable(name = "fileName") String fileName) throws FileNotFoundException {

        String path = datasetMapper.getDatasetPathByName(fileName);
        String download = path+fileName;
        File file = new File (download);
        InputStreamResource resource = new InputStreamResource ( new FileInputStream( file ) );

        HttpHeaders headers = new HttpHeaders();
        headers.add ( "Content-Disposition",String.format("attachment;filename=\"%s",fileName));
        headers.add ( "Cache-Control","no-cache,no-store,must-revalidate" );
        headers.add ( "Pragma","no-cache" );
        headers.add ( "Expires","0" );

        ResponseEntity<Object> responseEntity = ResponseEntity.ok()
                .headers ( headers )
                .contentLength ( file.length ())
                .contentType(MediaType.parseMediaType ( "application/txt" ))
                .body(resource);

        System.out.println("用户下载了文件："+fileName);
        return responseEntity;
    }

    @GetMapping("/download2/{fileName}")
    @ResponseBody
    public ResponseEntity<Object> downloadFile2(@PathVariable(name = "fileName") String fileName) throws FileNotFoundException {

        String path = myModelMapper.getModelPathByName(fileName);

        String download = path+fileName;
        File file = new File ( download);
        InputStreamResource resource = new InputStreamResource ( new FileInputStream( file ) );

        HttpHeaders headers = new HttpHeaders();
        headers.add ( "Content-Disposition",String.format("attachment;filename=\"%s",fileName));
        headers.add ( "Cache-Control","no-cache,no-store,must-revalidate" );
        headers.add ( "Pragma","no-cache" );
        headers.add ( "Expires","0" );

        ResponseEntity<Object> responseEntity = ResponseEntity.ok()
                .headers ( headers )
                .contentLength ( file.length ())
                .contentType(MediaType.parseMediaType ( "application/txt" ))
                .body(resource);

        System.out.println("用户下载了文件："+fileName);
        return responseEntity;
    }

}
