package com.rick.logindemo.mapper;

import com.rick.logindemo.entity.MyModel;
import com.rick.logindemo.entity.MyModel;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface MyModelMapper {
    public List<MyModel> getAllModel();
    public List<MyModel> getModelBySource(String source);
    public String getModelPathByName(String name);


    public void insertModel(MyModel myModel);
    public MyModel getModelById(Integer id);
    public void editModelById(MyModel model);
    public void deleteModelById(Integer id);
}
