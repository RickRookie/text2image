package com.rick.logindemo.controller;


import com.rick.logindemo.entity.Dataset;

import com.rick.logindemo.mapper.DatasetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;

@Controller
public class DatasetController {
    @Autowired
    DatasetMapper datasetMapper;

    @GetMapping("/datasets")
    public String list(Model model){
        Collection<Dataset> datasets = datasetMapper.getAllDataset();
        model.addAttribute("datasets",datasets);
        return "obj/datasets";
    }
    //来到添加论文页面
    @GetMapping("/adddataset")
    public String toAddDataset(){
        return "obj/addDataset";
    }

    //完成论文添加
    //SpringMvc 自动将请求参数和入参对象的属性进行一一绑定；要求
    //请求参数的名字和Javabean入参的对象里面的属性名是一样的
    @PostMapping("/addd")
    public String addDataset(Dataset dataset, Model model){
        //来到论文管理页面

        List<Dataset>  datasetList =  datasetMapper.getAllDataset();
        for(Dataset d:datasetList){
            if(dataset.getDatasetName().equals(d.getDatasetName())){

                model.addAttribute("addmsg","添加失败，因为数据集已存在");
                return "obj/addDataset";
            }
        }
        datasetMapper.insertDataset(dataset);
        System.out.println(dataset.toString());
        //redirect: 表示重定向到一个地址，/ 代表当前项目路径
        //forward 表示转发一个地址
        return "redirect:/datasets";
    }

    //来到修改页面，查出当前论文，在页面回显
    @GetMapping("/dataset/{id}")
    public String toEditPage(@PathVariable("id") Integer id, Model model){

        Dataset dataset = datasetMapper.getDatasetById(id);
        model.addAttribute("dataset",dataset);

        return "obj/editDataset";

    }
    //完成修改操作
    @PutMapping("/dataset")
    public String updateDataset(Dataset dataset){
       datasetMapper.editDatasetById(dataset);
        System.out.println("管理员修改了数据集："+dataset.toString());

        return "redirect:/datasets";
    }

    //删除
    @DeleteMapping("/dataset/{id}")

    public String deleteDataset(@PathVariable("id") Integer id){

        datasetMapper.deleteDatasetById(id);
        return "redirect:/datasets";

    }

}








