package com.rick.logindemo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@SpringBootApplication
@MapperScan("com.rick.logindemo.mapper")
public class LoginDemoApplication {
	@Bean
	public static PropertySourcesPlaceholderConfigurer placeholderConfigurer() {

		PropertySourcesPlaceholderConfigurer c = new PropertySourcesPlaceholderConfigurer();

		c.setIgnoreUnresolvablePlaceholders(true);

		return c;

	}

	public static void main(String[] args) {
		SpringApplication.run(LoginDemoApplication.class, args);
	}

}
