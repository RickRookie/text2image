package com.rick.logindemo.controller;



import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


@Controller
public class IndexController {



    @GetMapping("/adminlogin")
    public String login(){
        return "login";
    }

    @GetMapping("/")
    public String index(){


        return "redirect:/text2image";
    }






}
