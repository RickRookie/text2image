package com.rick.logindemo.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.io.*;


@Controller
public class AdminController {



    private static String fileUploadRootDir = null;
    private static String fileUploadRootDir1 = null;
    private static String fileUploadRootDir2= null;

    @Value( "${file.upload.root.dir.windows}" )
    String fileUploadRootDirWindows;

    @Value( "${file.upload.root.dir.windows1}" )
    String fileUploadRootDirWindows1;

    @Value( "${file.upload.root.dir.windows2}" )
    String fileUploadRootDirWindows2;


    @Value ( "${file.upload.root.dir.mac}" )
    String fileUploadRootDirMac;

    @Value ( "${file.upload.root.dir.linux}" )
    String fileUploadRootDirLinux;

    @Value ( "${file.upload.root.dir.linux1}" )
    String fileUploadRootDirLinux1;

    @Value ( "${file.upload.root.dir.linux2}" )
    String fileUploadRootDirLinux2;


//    private static Map<String, FileInfo> fileRepository = new HashMap<>();

    @PostConstruct
    public void initFileRepository(){

        String osName = System.getProperty("os.name");
        if (osName.startsWith("Mac OS")) {
            // 苹果
            fileUploadRootDir = fileUploadRootDirMac;
        } else if (osName.startsWith("Windows")) {
            // windows
            fileUploadRootDir = fileUploadRootDirWindows;
            fileUploadRootDir1 = fileUploadRootDirWindows1;
            fileUploadRootDir2 = fileUploadRootDirWindows2;

        } else {
            // unix or linux
            fileUploadRootDir = fileUploadRootDirLinux;
            fileUploadRootDir1 = fileUploadRootDirLinux1;
            fileUploadRootDir2 = fileUploadRootDirLinux2;
        }
    }

    @GetMapping("/admin")
    public String files(Model model){
//        Collection<FileInfo> files = fileRepository.values ();
//        model.addAttribute ( "files",files );
        return "dashboard";
    }





    @PostMapping(value = "/uploadp",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseBody
    public String fileUploadPaper(@RequestParam("file") MultipartFile file) throws IOException {

        File convertFile = new File ( fileUploadRootDir+file.getOriginalFilename ());
        convertFile.setWritable(true,false);
        FileOutputStream fileOutputStream = new FileOutputStream ( convertFile );
        fileOutputStream.write ( file.getBytes () );
        fileOutputStream.close ();


        return "File is upload successfully";
    }

    @PostMapping(value = "/uploadm",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseBody
    public String fileUploadModel(@RequestParam("file") MultipartFile file) throws IOException {

        File convertFile = new File ( fileUploadRootDir2+file.getOriginalFilename ());
        convertFile.setWritable(true,false);
        FileOutputStream fileOutputStream = new FileOutputStream ( convertFile );
        fileOutputStream.write ( file.getBytes () );
        fileOutputStream.close ();


        return "File is upload successfully";
    }

    @PostMapping(value = "/uploadd",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseBody
    public String fileUploadDataset(@RequestParam("file") MultipartFile file) throws IOException {

        File convertFile = new File ( fileUploadRootDir1+file.getOriginalFilename ());
        convertFile.setWritable(true,false);
        FileOutputStream fileOutputStream = new FileOutputStream ( convertFile );
        fileOutputStream.write ( file.getBytes () );
        fileOutputStream.close ();


        return "File is upload successfully";
    }






}
