package com.rick.logindemo.controller;


import com.rick.logindemo.entity.Paper;
import com.rick.logindemo.mapper.PaperMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;

@Controller
public class PaperController {
    @Autowired
    PaperMapper paperMapper;

    @GetMapping("/papers")
    public String list(Model model){
        Collection<Paper> papers = paperMapper.getAllPaper();
        model.addAttribute("papers",papers);
        return "obj/papers";
    }
//来到添加论文页面
    @GetMapping("/addpaper")
    public String toAddPaper(){
        return "obj/addPaper";
    }

    //完成论文添加
    //SpringMvc 自动将请求参数和入参对象的属性进行一一绑定；要求
    //请求参数的名字和Javabean入参的对象里面的属性名是一样的
    @PostMapping("/addp")
    public String addPaper(Paper paper, Model model){
        //来到论文管理页面

        List<Paper>  paperList =  paperMapper.getAllPaper();
        for(Paper p:paperList){
            if(paper.getPaperName().equals(p.getPaperName())){

                model.addAttribute("addmsg","添加失败，因为论文已存在");
                return "obj/addPaper";
            }
        }
        paperMapper.insertPaper(paper);
        System.out.println(paper.toString());
        //redirect: 表示重定向到一个地址，/ 代表当前项目路径
        //forward 表示转发一个地址
        return "redirect:/papers";
    }

    //来到修改页面，查出当前论文，在页面回显
    @GetMapping("/paper/{id}")
    public String toEditPage(@PathVariable("id") Integer id, Model model){

        Paper paper = paperMapper.getPaperById(id);
        model.addAttribute("paper",paper);

        return "obj/editPaper";

    }
    //完成修改操作
    @PutMapping("/paper")
    public String updatePaper(Paper paper){
        paperMapper.editPaperById(paper);
        System.out.println("管理员修改了论文："+paper.toString());

        return "redirect:/papers";
    }

//删除
    @DeleteMapping("/paper/{id}")

    public String deletePaper(@PathVariable("id") Integer id){

        paperMapper.deletePaperById(id);
        return "redirect:/papers";

    }

}








