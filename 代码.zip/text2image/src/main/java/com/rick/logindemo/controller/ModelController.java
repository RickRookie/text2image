package com.rick.logindemo.controller;


import com.rick.logindemo.entity.MyModel;
import com.rick.logindemo.entity.MyModel;
import com.rick.logindemo.entity.Paper;
import com.rick.logindemo.mapper.MyModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;

@Controller
public class ModelController {
    @Autowired
    MyModelMapper modelMapper;

    @GetMapping("/models")
    public String list(Model model){
        Collection<MyModel> models = modelMapper.getAllModel();
        model.addAttribute("models",models);
        return "obj/Models";
    }
    //来到添加论文页面
    @GetMapping("/addmodel")
    public String toAddmodel(){
        return "obj/addModel";
    }

    //完成论文添加
    //SpringMvc 自动将请求参数和入参对象的属性进行一一绑定；要求
    //请求参数的名字和Javabean入参的对象里面的属性名是一样的
    @PostMapping("/addm")
    public String addModel(MyModel model, Model model1){
        //来到论文管理页面

        List<MyModel> paperList =  modelMapper.getAllModel();
        for(MyModel m:paperList){
            if(model.getModelName().equals(m.getModelName())){

                model1.addAttribute("addmsg","添加失败，因为模型已存在");
                return "obj/addPaper";
            }
        }

        modelMapper.insertModel(model);
        System.out.println(model.toString());
        //redirect: 表示重定向到一个地址，/ 代表当前项目路径
        //forward 表示转发一个地址
        return "redirect:/models";
    }

    //来到修改页面，查出当前论文，在页面回显
    @GetMapping("/model/{id}")
    public String toEditPage(@PathVariable("id") Integer id, Model model){

        MyModel myModel = modelMapper.getModelById(id);
        model.addAttribute("model",myModel);

        return "obj/editModel";

    }
    //完成修改操作
    @PutMapping("/model")
    public String updateModel(MyModel myModel){
        modelMapper.editModelById(myModel);
        System.out.println("管理员修改了数据集："+myModel.toString());

        return "redirect:/models";
    }

    //删除
    @DeleteMapping("/model/{id}")

    public String deleteModel(@PathVariable("id") Integer id){

        modelMapper.deleteModelById(id);
        return "redirect:/models";

    }

}








