-- MySQL dump 10.13  Distrib 5.7.11, for Linux (x86_64)
--
-- Host: localhost    Database: jdbc
-- ------------------------------------------------------
-- Server version	5.7.11-0ubuntu6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'rick','7758'),(2,'joy','7758');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataset`
--

DROP TABLE IF EXISTS `dataset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET latin1 NOT NULL,
  `address` varchar(300) CHARACTER SET latin1 NOT NULL,
  `source` varchar(200) CHARACTER SET latin1 NOT NULL,
  `description` varchar(2000) CHARACTER SET latin1 NOT NULL,
  `datasetName` varchar(200) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataset`
--

LOCK TABLES `dataset` WRITE;
/*!40000 ALTER TABLE `dataset` DISABLE KEYS */;
INSERT INTO `dataset` VALUES (2,'birds.tar.gz','/media/sdu/c699c586-c239-4ece-b17d-0498451577b51/2020project/AZtest/files/dataset/','github','birds dataset','birds'),(3,'coco_bicycle.tar.gz','/media/sdu/c699c586-c239-4ece-b17d-0498451577b51/2020project/AZtest/files/dataset/','github','coco_bicycle datasets','coco_bicycle'),(4,'flower.tar.gz','/media/sdu/c699c586-c239-4ece-b17d-0498451577b51/2020project/AZtest/files/dataset/','github','flower dataset','flower');
/*!40000 ALTER TABLE `dataset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model`
--

DROP TABLE IF EXISTS `model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET latin1 NOT NULL,
  `address` varchar(200) CHARACTER SET latin1 NOT NULL,
  `source` varchar(300) CHARACTER SET latin1 NOT NULL,
  `description` varchar(2000) CHARACTER SET latin1 NOT NULL,
  `modelName` varchar(300) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model`
--

LOCK TABLES `model` WRITE;
/*!40000 ALTER TABLE `model` DISABLE KEYS */;
INSERT INTO `model` VALUES (1,'StackGAN-v2-master.zip','/media/sdu/c699c586-c239-4ece-b17d-0498451577b51/2020project/AZtest/files/model/','https://github.com/hanzhanggit/StackGAN-v2','Pytorch implementation for reproducing StackGAN_v2 results in the paper StackGAN++: Realistic Image Synthesis with Stacked Generative Adversarial Networks by Han Zhang*, Tao Xu*, Hongsheng Li, Shaoting Zhang, Xiaogang Wang, Xiaolei Huang, Dimitris Metaxas.','StackGAN-v2'),(2,'MirrorGAN-master.zip','/media/sdu/c699c586-c239-4ece-b17d-0498451577b51/2020project/AZtest/files/model/','https://github.com/qiaott/MirrorGAN','Pytorch implementation for Paper MirrorGAN: Learning Text-to-image Generation by Redescription by Tingting Qiao, Jing Zhang, Duanqing Xu, Dacheng Tao. (The work was performed when Tingting Qiao was a visiting student at UBTECH Sydney AI Centre in the School of Computer Science, FEIT, the University of Sydney).','MirrorGAN');
/*!40000 ALTER TABLE `model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_table`
--

DROP TABLE IF EXISTS `new_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_table`
--

LOCK TABLES `new_table` WRITE;
/*!40000 ALTER TABLE `new_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `new_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paper`
--

DROP TABLE IF EXISTS `paper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET latin1 NOT NULL,
  `author` varchar(800) CHARACTER SET latin1 NOT NULL,
  `address` varchar(300) CHARACTER SET latin1 NOT NULL,
  `releaseTime` varchar(45) CHARACTER SET latin1 NOT NULL,
  `source` varchar(200) CHARACTER SET latin1 NOT NULL,
  `description` varchar(2000) CHARACTER SET latin1 NOT NULL,
  `paperName` varchar(500) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paper`
--

LOCK TABLES `paper` WRITE;
/*!40000 ALTER TABLE `paper` DISABLE KEYS */;
INSERT INTO `paper` VALUES (1,'Yang_Stacked_Attention_Networks_CVPR_2016_paper.pdf','Zichao Yang, Xiaodong He, Jianfeng Gao, Li Deng, Alex Smola','/media/sdu/c699c586-c239-4ece-b17d-0498451577b51/2020project/AZtest/files/paper/','2016','IEEE Conference on Computer Vision and Pattern Recognition(CVPR)','This paper presents stacked attention networks (SANs) that learn to answer natural language questions from images. ','Stacked Attention Networks for Image Question Answering'),(2,'Zhang_StackGAN_Text_to_ICCV_2017_paper.pdf','Han Zhang, Tao Xu, Hongsheng Li, Shaoting Zhang, Xiaogang Wang, Xiaolei Huang, Dimitris Metaxas','/media/sdu/c699c586-c239-4ece-b17d-0498451577b51/2020project/AZtest/files/paper/','2017','IEEE International Conference on Computer Vision(ICCV)','In this paper, we propose Stacked Generative Adversarial Networks (StackGAN) to generate 256x256 photo-realistic images conditioned on text descriptions. We decompose the hard problem into more manageable sub-problems through a sketch-refinement process.','StackGAN: Text to Photo-realistic Image Synthesis with Stacked Generative Adversarial Networks'),(16,'Generative Adversarial Text to Image Synthesis.pdf','Scott Reed, Zeynep Akata, Xinchen Yan, Lajanugen Logeswaran, Bernt Schiele, Honglak Lee','/media/sdu/c699c586-c239-4ece-b17d-0498451577b51/2020project/AZtest/files/paper/','2016','International Conference on Machine Learning(ICML)','Automatic synthesis of realistic images from text would be interesting and useful, but current AI systems are still far from this goal. However, in recent years generic and powerful recurrent neural network architectures have been developed to learn discriminative text feature representations. Meanwhile, deep convolutional generative adversarial networks (GANs) have begun to generate highly compelling images of specific categories','Generative Adversarial Text to Image Synthesis'),(18,'StackGAN++ Realistic Image Synthesis with Stacked Generative Adversarial Networks .pdf','Han Zhang, Tao Xu, Hongsheng Li, Shaoting Zhang, Senior Member, Xiaogang Wang, Xiaolei Huang, Dimitris N. Metaxas','/media/sdu/c699c586-c239-4ece-b17d-0498451577b51/2020project/AZtest/files/paper/','2017','ICCV','Although Generative Adversarial Networks (GANs) have shown remarkable success in various tasks, they still face\r\nchallenges in generating high quality images. In this paper, we propose Stacked Generative Adversarial Networks (StackGANs)\r\naimed at generating high-resolution photo-realistic images. First, we propose a two-stage generative adversarial network architecture,\r\nStackGAN-v1, for text-to-image synthesis. The Stage-I GAN sketches the primitive shape and colors of a scene based on a given text\r\ndescription, yielding low-resolution images. The Stage-II GAN takes Stage-I results and the text description as inputs, and generates\r\nhigh-resolution images with photo-realistic details.','StackGAN++: Realistic Image Synthesis with Stacked Generative Adversarial Networks');
/*!40000 ALTER TABLE `paper` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-02 19:44:17
